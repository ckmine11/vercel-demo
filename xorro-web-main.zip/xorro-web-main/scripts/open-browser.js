var openBrowser = require('open-web-browser')

openBrowser('http://localhost:3000')
