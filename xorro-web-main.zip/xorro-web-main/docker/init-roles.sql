CREATE ROLE fundability_service WITH LOGIN PASSWORD 'password';
CREATE ROLE notification_service WITH LOGIN PASSWORD 'password';
CREATE ROLE auth_service WITH LOGIN PASSWORD 'password';
CREATE ROLE campaign_service WITH LOGIN PASSWORD 'password';
CREATE ROLE peeps_user_service WITH LOGIN PASSWORD 'password';
