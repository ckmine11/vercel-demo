module.exports = {
  overrides: [
    {
      files: ['./*'],
      rules: {
        '@typescript-eslint/naming-convention': 'off',
      },
    },
  ],
}
