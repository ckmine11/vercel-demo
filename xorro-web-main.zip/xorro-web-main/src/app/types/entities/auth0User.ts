import { type User } from '@auth0/auth0-spa-js'

// Using our own type alias for the Auth0 User type
export type TAuth0User = User
