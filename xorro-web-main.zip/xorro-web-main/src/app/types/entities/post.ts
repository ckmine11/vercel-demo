export type TPost = {
  content: string
  id: string
  title: string
}
