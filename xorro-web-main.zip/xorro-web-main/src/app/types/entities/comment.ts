export type TComment = {
  author: string
  content: string
  id: string
}
