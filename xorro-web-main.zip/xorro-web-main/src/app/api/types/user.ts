export type TUser = {
  dateOfBirth: string
  name: string
  role: 'admin' | 'editor' | 'reader'
}
